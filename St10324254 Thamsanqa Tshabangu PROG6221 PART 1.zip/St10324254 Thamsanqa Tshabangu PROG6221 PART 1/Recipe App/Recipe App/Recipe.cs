﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App
{
    internal class Recipe
    {
        //Stored the ingredients and steps in arrays
public List<Ingredient> Ingredients {  get; set; }
        public List<string> Steps {  get; set; }

        public Recipe() { 
        
        Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        
        }

    }
}

