﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Recipe recipe = new Recipe();
            List<Ingredient> originalIngredients = new List<Ingredient>();

            //A function to enter recipe details
            void EnterRecipeDetails()
            {
                try

                {
                    Console.Write("Enter number of ingredients: ");
                    int ingredientCount = int.Parse(Console.ReadLine());

                    for (int i = 0; i < ingredientCount; i++)
                    {
                        Console.Write($"Enter the name of ingredient {i + 1}: ");
                        string name = Console.ReadLine();

                        Console.Write($"Enter the quantity of {name}: ");
                        double quantity = double.Parse(Console.ReadLine());

                        Console.Write($"Enter the unit of measurement for {name}: ");
                        string measurement = Console.ReadLine();

                        recipe.Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Measurement = measurement });
                    }

                    Console.Write("Enter number of steps: ");
                    int stepCount = int.Parse(Console.ReadLine());
                    for (int i = 0; i < stepCount; i++)
                    {
                        Console.Write($"Enter step {i + 1}: ");
                        string step = Console.ReadLine();
                        recipe.Steps.Add(step);
                    }

                    Console.WriteLine("Recipe details entered successfully.");

                    // Stores the original ingredient quantities when they are entered.

                    originalIngredients = new List<Ingredient>(recipe.Ingredients);
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Error: {e.Message}. Please try to enter again.");
                }
            }
            //Method that will result in displaying the recipe

            void ShowRecipe()
            {
                Console.WriteLine("\nRecipe:");
                Console.WriteLine("Ingredients:");
                foreach (var ingredient in recipe.Ingredients)
                {
                    Console.WriteLine($"- {ingredient.Quantity} {ingredient.Measurement} of {ingredient.Name}");
                }

                Console.WriteLine("\nSteps:");
                for (int i = 0; i < recipe.Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {recipe.Steps[i]}");
                }

            }
            //Method to request the scaling of the recipe

            void ScaleRecipe(double factor)
            {

                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.Quantity *= factor;
                }


            }
            //implemented this method, which clears the current list of ingredients and then adds
            //all the ingredients from originalIngredients back into the recipe.

            void ResetQuantities() {

                recipe.Ingredients.Clear();
                recipe.Ingredients.AddRange(originalIngredients);
                Console.WriteLine("Quantities reset to their original values.");

            }

            //Fuction clears all the data saved.

            void ClearData()
            {
                Console.Write("Are you sure you want to clear all data? (Yes/No): ");
                string input = Console.ReadLine();

                if (input == "Yes")
                {
                    recipe = new Recipe();
                    Console.WriteLine("All data has been cleard.");
                }

            }

            while (true)
            {
                //Prompts the user to choose an option.
                Console.WriteLine("1. Enter recipe details");
                Console.WriteLine("2. Show Recipe");
                Console.WriteLine("3. Request to scale recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear all data");
                Console.WriteLine("6. Exit app");

                Console.WriteLine("Option: ");

                int option;
                if (!int.TryParse(Console.ReadLine(), out option))
                {
                    Console.WriteLine("Invalid option. Please enter a number sir.");
                    continue;
                }

                switch (option)
                {
                    case 1:
                        EnterRecipeDetails();
                        break;
                    case 2:
                        ShowRecipe();
                        break;
                    case 3:
                        Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                        double scaleFactor;
                        if (!double.TryParse(Console.ReadLine(), out scaleFactor))
                        {
                            Console.WriteLine("Invalid scaling factor. Please enter a valid number.");
                            continue;
                        }
                        ScaleRecipe(scaleFactor);
                        break;
                    case 4:
                        ResetQuantities(); 
                        break;
                    case 5:
                        ClearData();
                        break;
                    case 6:
                        Environment.Exit(0); // Method for exiting the app/program.
                        break;

                        default: 
                        Console.WriteLine("Invalid input, please try to enter a valid option. ");

                        break;

                }


            }

        }
    }
}
