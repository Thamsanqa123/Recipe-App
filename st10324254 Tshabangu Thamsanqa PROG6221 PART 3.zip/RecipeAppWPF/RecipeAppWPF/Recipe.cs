﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeAppWPF
{
    internal class Recipe

    {
         
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe(string name)
        {
            
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void DisplayTotalCalories()
        {
            double totalCalories = Ingredients.Sum(ingredient => ingredient.Calories);
            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");
            }

            if (totalCalories <= 100)
            {
                Console.WriteLine("This recipe is low in calories.");
            }
            else if (totalCalories <= 200)
            {
                Console.WriteLine("This recipe is moderate in calories.");
            }
            else
            {
                Console.WriteLine("This recipe is high in calories.");
            }
        }
    }
}
