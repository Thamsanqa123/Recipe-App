﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeAppWPF
{
    public partial class MainWindow : Window
    {

        private List<Ingredient> originalIngredients = new List<Ingredient>();
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }
        //prompts the user to enter their recipes followed by the steps that must be taken
        private void EnterRecipe_Click(object sender, RoutedEventArgs e)
        {
            var enterRecipeWindow = new EnterRecipeWindow();
            if (enterRecipeWindow.ShowDialog() == true)
            {
                var newRecipe = enterRecipeWindow.NewRecipe;
                recipes.Add(newRecipe);
                originalIngredients.AddRange(newRecipe.Ingredients.Select(ingredient => (Ingredient)ingredient.Clone()));
                MessageBox.Show("Recipe details entered successfully.");
            }
        }

        //method allows the program to show the recipe.
        private void ShowRecipe_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string recipeName = txtRecipeName.Text;

                Recipe selectedRecipe = recipes.Find(recipe => recipe.Name == recipeName);
                if (selectedRecipe != null)
                {
                    string recipeDetails = $"{selectedRecipe.Name}\n\nIngredients:\n";
                    foreach (var ingredient in selectedRecipe.Ingredients)
                    {
                        recipeDetails += $"- {ingredient.Quantity} {ingredient.Measurement} of {ingredient.Name} ({ingredient.Calories} calories)\n";
                    }
                    recipeDetails += "\nSteps:\n";
                    for (int i = 0; i < selectedRecipe.Steps.Count; i++)
                    {
                        recipeDetails += $"{i + 1}. {selectedRecipe.Steps[i]}\n";
                    }

                    var recipeDetailsWindow = new RecipeDetailsWindow(recipeDetails);
                    recipeDetailsWindow.Show();
                }
                else
                {
                    MessageBox.Show("Recipe not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void DisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                lstRecipes.ItemsSource = recipes.Select(recipe => recipe.Name).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double scaleFactor = double.Parse(txtScalingFactor.Text);

                foreach (var recipe in recipes)
                {
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        ingredient.Quantity *= scaleFactor;
                    }
                }

                MessageBox.Show("Recipe scaled successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}. Please enter a valid scaling factor.");
            }
        }

        private void ResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                foreach (var recipe in recipes)
                {
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        var originalIngredient = originalIngredients.Find(i => i.Name == ingredient.Name);

                        if (originalIngredient != null)
                        {
                            ingredient.Quantity = originalIngredient.Quantity;
                        }
                    }
                }

                MessageBox.Show("Quantities reset to their original values.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void ClearData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to clear all data?", "Clear Data", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    recipes.Clear();
                    originalIngredients.Clear();
                    lstRecipes.ItemsSource = null;

                    MessageBox.Show("All data has been cleared.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void FilterByIngredient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ingredientFilter = txtIngredientFilter.Text.ToLower();

                var filteredRecipes = recipes.Where(recipe =>
                    recipe.Ingredients.Any(ingredient => ingredient.Name.ToLower().Contains(ingredientFilter))
                ).ToList();

                DisplayFilteredRecipes(filteredRecipes);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void FilterByFoodGroup_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string selectedFoodGroup = (cmbFoodGroupFilter.SelectedItem as ComboBoxItem)?.Content.ToString();

                var filteredRecipes = recipes.Where(recipe =>
                    recipe.Ingredients.Any(ingredient => ingredient.Group.ToString() == selectedFoodGroup)
                ).ToList();

                DisplayFilteredRecipes(filteredRecipes);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void FilterByMaxCalories_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double maxCalories = double.Parse(txtMaxCaloriesFilter.Text);

                var filteredRecipes = recipes.Where(recipe =>
                    recipe.Ingredients.Sum(ingredient => ingredient.Calories) <= maxCalories
                ).ToList();

                DisplayFilteredRecipes(filteredRecipes);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void DisplayFilteredRecipes(List<Recipe> filteredRecipes)
        {
            lstRecipes.ItemsSource = filteredRecipes.Select(recipe => recipe.Name).ToList();
        }

        private void ClearInputFields()
        {
            txtRecipeName.Clear();
            txtScalingFactor.Clear();
            txtIngredientFilter.Clear();
            cmbFoodGroupFilter.SelectedIndex = -1;
            txtMaxCaloriesFilter.Clear();
        }
    }
}
