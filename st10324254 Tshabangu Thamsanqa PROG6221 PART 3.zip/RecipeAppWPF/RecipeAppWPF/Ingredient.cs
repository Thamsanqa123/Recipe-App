﻿using System;

namespace RecipeAppWPF
{
    internal class Ingredient: ICloneable
    {
        
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Measurement { get; set; }
        public double Calories { get; set; }
        public FoodGroup Group { get; set; }

        public enum FoodGroup
        {
            Vegetable,
            Grain,
            Meat,
            Dairy,
            Fruit,
            Other
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
