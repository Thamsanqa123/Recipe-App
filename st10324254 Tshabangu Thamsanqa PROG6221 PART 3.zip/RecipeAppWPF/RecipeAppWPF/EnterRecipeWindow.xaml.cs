﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using RecipeAppWPF;

namespace RecipeAppWPF
{
    public partial class EnterRecipeWindow : Window
    {
        public Recipe NewRecipe { get; private set; }
        private List<Ingredient> ingredients = new List<Ingredient>();
        private List<string> steps = new List<string>();

        public EnterRecipeWindow()
        {
            InitializeComponent();
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            var ingredientWindow = new IngredientWindow();
            if (ingredientWindow.ShowDialog() == true)
            {
                ingredients.Add(ingredientWindow.NewIngredient);
                spIngredients.Children.Add(new Label { Content = ingredientWindow.NewIngredient.ToString() });
            }
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            var stepWindow = new StepWindow();
            if (stepWindow.ShowDialog() == true)
            {
                steps.Add(stepWindow.NewStep);
                spSteps.Children.Add(new Label { Content = stepWindow.NewStep });
            }
        }
        //button to save the recipe the user has entered
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            NewRecipe = new Recipe(txtRecipeName.Text)
            {
                Ingredients = ingredients,
                Steps = steps
            };
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}