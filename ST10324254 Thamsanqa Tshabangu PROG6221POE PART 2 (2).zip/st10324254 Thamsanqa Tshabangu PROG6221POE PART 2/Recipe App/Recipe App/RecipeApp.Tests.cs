﻿using NUnit.Framework;
using Recipe_App;
using System.Collections.Generic;

namespace RecipeApp.Tests
{
    public class RecipeTests
    {
        [Test]
        public void TotalCalories_CalculatesCorrectly()
        {
            // Arrange
            var ingredients = new List<Ingredient>
            {
                new Ingredient { Name = "Sugar", Quantity = 1, Calories = 50 },
                new Ingredient { Name = "Flour", Quantity = 2, Calories = 100 },
                new Ingredient { Name = "Butter", Quantity = 0.5, Calories = 200 }
            };
            var recipe = new Recipe("Test Recipe") { Ingredients = ingredients };

            // Act
            var totalCalories = recipe.TotalCalories();

            // Assert
            Assert.AreEqual(300, totalCalories);
        }

        [Test]
        public void TotalCalories_ReturnsZeroForEmptyRecipe()
        {
            // Arrange
            var recipe = new Recipe("Empty Recipe");

            // Act
            var totalCalories = recipe.TotalCalories();

            // Assert
            Assert.AreEqual(0, totalCalories);
        }
    }
}
