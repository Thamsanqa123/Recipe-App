﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App
{
    internal class Recipe
    {
        //stores the name of each recipe
        public string Name { get; set; }

        //Stored the ingredients and steps in arrays
public List<Ingredient> Ingredients {  get; set; }
        public List<string> Steps {  get; set; }

        public Recipe(string name) { 
        
            Name = name;
        Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        
        }

        public void DisplayTotalCalories()
        {
            double totalCalories = Ingredients.Sum(ingredient => ingredient.Calories);
            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");
            }

            // Explanation specific to certain ranges of calories
            if (totalCalories <= 100)
            {
                Console.WriteLine("This recipe is low in calories.");
            }
            else if (totalCalories <= 200)
            {
                Console.WriteLine("This recipe is moderate in calories.");
            }
            else
            {
                Console.WriteLine("This recipe is high in calories.");
            }
        }
    }

}


