﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Recipe_App.Ingredient;
using static Recipe_App.Recipe;


namespace Recipe_App
{
    internal class Program
    {



        static void Main(string[] args)
        {
            List<Ingredient> originalIngredients = new List<Ingredient>();
             List<Recipe> recipes = new List<Recipe>();


            //A function to enter recipe details
            void EnterRecipeDetails()
            {
                try

                {
                    Console.Write("Enter name of the recipe: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter number of ingredients: ");
                    int ingredientCount = int.Parse(Console.ReadLine());

                    Recipe recipe = new Recipe(name);


                    for (int i = 0; i < ingredientCount; i++)
                    {
                        Console.Write($"Enter the name of ingredient {i + 1}: ");
                        string ingredientName = Console.ReadLine();

                        Console.Write($"Enter the quantity of {ingredientName}: ");
                        double quantity = double.Parse(Console.ReadLine());

                        Console.Write($"Enter the unit of measurement for {ingredientName}: ");
                        string measurement = Console.ReadLine();

                        Console.Write($"Enter the amount of calories for {ingredientName}: ");
                        double calories = double.Parse(Console.ReadLine());

                        Console.Write($"Enter the food group for {ingredientName} (Vegetable/Grain/Meat/Dairy/Fruit/Other): ");
                        string groupStr = Console.ReadLine();
                        Enum.TryParse(groupStr, out Ingredient.FoodGroup group);

                        recipe.Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Measurement = measurement, Calories = calories, Group = group });
                    }

                    Console.Write("Enter number of steps: ");
                    int stepCount = int.Parse(Console.ReadLine());
                    for (int i = 0; i < stepCount; i++)
                    {
                        Console.Write($"Enter step {i + 1}: ");
                        string step = Console.ReadLine();
                        recipe.Steps.Add(step);
                    }

                    recipes.Add(recipe);


                    Console.WriteLine("Recipe details entered successfully.");

                    // Stores the original ingredient quantities when they are entered.

                    originalIngredients = new List<Ingredient>(recipe.Ingredients);
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Error: {e.Message}. Please try to enter again.");
                }
            }

            void ShowRecipeList()
            {
                Console.WriteLine("List of Recipes:");
                var sortedRecipes = recipes.OrderBy(recipe => recipe.Name);
                foreach (var recipe in sortedRecipes)
                {
                    Console.WriteLine(recipe.Name);
                }
            }


            //Method that will result in displaying the recipe

            void ShowRecipe()
            {
                Console.Write("Enter the name of the recipe you want to display: ");
                string recipeName = Console.ReadLine();

                Recipe selectedRecipe = recipes.Find(recipe => recipe.Name == recipeName);
                if (selectedRecipe != null)
                {
                    Console.WriteLine($"\n{selectedRecipe.Name}:");
                    selectedRecipe.DisplayTotalCalories();
                    Console.WriteLine("\nIngredients:");
                    foreach (var ingredient in selectedRecipe.Ingredients)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"- {ingredient.Quantity} {ingredient.Measurement} of {ingredient.Name} ({ingredient.Calories} calories)");
                    }
                    Console.WriteLine("\nSteps:");
                    for (int i = 0; i < selectedRecipe.Steps.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {selectedRecipe.Steps[i]}");
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Recipe not found.");
                }

            }
            //Method to request the scaling of the recipe

            void ScaleRecipe(double factor)
            {
                foreach (var recipe in recipes)
                {
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        ingredient.Quantity *= factor;
                    }

                }

                Console.WriteLine("Recipe scaled successfully.");

            }
            //implemented this method, which clears the current list of ingredients and then adds
            //all the ingredients from originalIngredients back into the recipe.

            void ResetQuantities() {

                foreach (var recipe in recipes)
                {
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        var originalIngredient = originalIngredients.Find(i => i.Name == ingredient.Name);

                        // Reset the quantity
                        if (originalIngredient != null)
                        {
                            ingredient.Quantity = originalIngredient.Quantity;
                        }
                    }
                }
                Console.WriteLine("Quantities reset to their original values.");
            }

        

            //Fuction clears all the data saved.

            void ClearData()
            {
                Console.Write("Are you sure you want to clear all data? (Yes/No): ");
                string input = Console.ReadLine();

                if (input == "Yes")
                {
                    recipes.Clear();
                    Console.WriteLine("All data has been cleard!");
                }

            }

            while (true)
            {
                //Prompts the user to choose an option.
                Console.WriteLine("1. Enter recipe details");
                Console.WriteLine("2. Show Recipe");
                Console.WriteLine("3. Display list of recipes");
                Console.WriteLine("4. Request to scale recipe");
                Console.WriteLine("5. Reset Quantities");
                Console.WriteLine("6. Clear all data");
                Console.WriteLine("7. Exit app");

                Console.WriteLine("Option: ");

                int option;
                if (!int.TryParse(Console.ReadLine(), out option))
                {
                    Console.WriteLine("Invalid option. Please enter a number sir.");
                    continue;
                }

                switch (option)
                {
                    case 1:
                        EnterRecipeDetails();
                        break;
                    case 2:
                        ShowRecipe();
                        break;
                    case 3:
                        ShowRecipeList();
                        break;
                    case 4:
                        Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                        double scaleFactor;
                        if (!double.TryParse(Console.ReadLine(), out scaleFactor))
                        {
                            Console.WriteLine("Invalid scaling factor. Please enter a valid number.");
                            continue;
                        }
                        ScaleRecipe(scaleFactor);
                        break;
                    case 5:
                        ResetQuantities(); 
                        break;
                    case 6:
                        ClearData();
                        break;
                    case 7:
                        Environment.Exit(0); // Method for exiting the app/program.
                        break;

                        default: 
                        Console.WriteLine("Invalid input, please try to enter a valid option. ");

                        break;

                }


            }

        }
    }
}
